i very happy for you can use the voicebank.
——
——
——
——
——
——
——
——
——
——
can
|
|
|
1.Second Reposting
2.Modify oto.ini file
3.Second creation
4.Praise?
—
—
—
—
—
—
can't
|
|
|
1.Modify oto.ini in bad faith with inferior quality
2.Malicious attacks on the author with inferior aspects
3.Modify the image
4.Reprinted without indicating the original author
+
+
+
+
+
+
+
+
+
+
readme
|First, I am Chinese and have an accent.Thank you for your understanding.
|Second, publish the work created with this work, and mark the author, such as: 《igaku(feat... uovi-yuleeyeen、kasane-teto》。
|Thirdly, the recording sheet was made by myself, which was inconvenient. The recording sheet is also available.
+
+
+
+
+
+
Thanks for reading！！！
